import 'package:flutter/material.dart';
import 'dart:math';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'حالات عربية 2026',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<String> quotes = [
    "اللهم إني توكلت عليك فاكفني",
    "من جد وجد ومن زرع حصد",
    "الحياة قصيرة ابتسم",
    "الله لا يخيب ظن عبد به",
    "سأعمل حتى يمل الفشل مني",
    "أحبك كثر ما في الدنيا حب",
    "بعضهم يوجعك بسكوته أكثر من كلامه",
    "جمعة مباركة",
    "لا تثق كثيراً ولا تكره أحداً",
    "صباح الخير للقلوب النقية",
    "يارب حقق لي ما أتمنى",
    "الرزق على الله",
    "خليك قوي",
    "القادم أجمل بإذن الله",
    "الحمدلله على كل حال",
  ];
  
  String currentQuote = "";

  @override
  void initState() {
    super.initState();
    getRandomQuote();
  }

  void getRandomQuote() {
    setState(() {
      currentQuote = quotes[Random().nextInt(quotes.length)];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('حالات عربية 2026')),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Card(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(currentQuote, style: TextStyle(fontSize: 22), textAlign: TextAlign.center),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(onPressed: getRandomQuote, child: Text('حالة جديدة')),
            ],
          ),
        ),
      ),
    );
  }
}
